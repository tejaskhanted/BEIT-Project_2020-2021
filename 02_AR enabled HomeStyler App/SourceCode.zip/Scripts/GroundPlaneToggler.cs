using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;

[RequireComponent(typeof(ARPlaneManager))]

public class GroundPlaneToggler : MonoBehaviour
{
    private ARPlaneManager planeManager;
    [SerializeField] private GameObject Marker;
    [SerializeField] private Text toggleButtonText;

    private void Awake()
    {
        planeManager = GetComponent<ARPlaneManager>();
        toggleButtonText.text = "Disable \n Ground Plane \n Detection";
    }

    public void TogglePlaneDetection()
    {
        planeManager.enabled = !planeManager.enabled;
        string togglebuttonMessage = "";

        if (planeManager.enabled)
        {
            togglebuttonMessage = "Disable \n Ground Plane \n Detection";
            Marker.SetActive(true);
            SetAllPlanesActive(true);
        }
        else
        {
            togglebuttonMessage = "Enable \n Ground Plane \n Detection";
            Marker.SetActive(false);
            SetAllPlanesActive(false);
        }
        toggleButtonText.text = togglebuttonMessage;
    }

    private void SetAllPlanesActive(bool value)
    {
        foreach(var plane in planeManager.trackables)
        {
            plane.gameObject.SetActive(value);
        }
    }
}
