using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WelcomeUI : MonoBehaviour
{
    [SerializeField] private GameObject welcomePanel;
    [SerializeField] private Button dismissButton;

    private void Awake()
    {
        dismissButton.onClick.AddListener(Dismiss);
    }

    private void Dismiss()
    {
        welcomePanel.SetActive(false);
    }
}
