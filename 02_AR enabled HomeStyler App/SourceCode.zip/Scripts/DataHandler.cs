﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.AddressableAssets;

public class DataHandler : MonoBehaviour
{
    private GameObject furniture;

    private Sprite furniture_img;
    private string furniture_name;
    private string seller;
    private string price;
    private string dimensions;
    private string materials_used;
    private string description;
    private int v_number;
    private Sprite v1;
    private Sprite v2;
    private Sprite v3;
    private Sprite v4;

    private string HyperLink;


    [SerializeField] private ButtonManager buttonPrefab;
    [SerializeField] private GameObject buttonContainer;
    [SerializeField] private List<Item> _items;
    
    [SerializeField] private string label;

    private int current_id = 0;

    private static DataHandler instance;
    public static DataHandler Instance                                           //Instance of DataManager
    { 
        get
        {
            if(instance == null)
            {
                instance = FindObjectOfType<DataHandler>();
            }
            return instance;
        }
    }

    private async void Start()
    {
        _items = new List<Item>();                                                //Initialize the list
        await Get(label);                                                         //Get the label string
        //LoadItems();
        CreateButtons();                                                          //Call the Create buttons function
    }

    void CreateButtons()
    {
        foreach (Item i in _items)
        {
            ButtonManager b = Instantiate(buttonPrefab, buttonContainer.transform);
            b.ItemId = current_id;
            b.ButtonTexture = i.itemImage;
            current_id++;
        }
    }
    //here
    public void SetFurnitureInfo(int id)
    {
        furniture_img = _items[id].itemImage;
        furniture_name = _items[id].ItemName;
        seller = _items[id].Seller;
        materials_used = _items[id].Material;
        price = _items[id].price;
        dimensions = _items[id].Dimensions;
        description = _items[id].Description;
        HyperLink = _items[id].Hyperlink;
        v_number = _items[id].VariantNumbers;
        v1 = _items[id].VariantImage1;
        v2 = _items[id].VariantImage2;
        v3 = _items[id].VariantImage3;
        v4 = _items[id].VariantImage4;
    }

    //to here

    public void SetFurniture(int id)
    {
        furniture = _items[id].itemPrefab;
    }

    public GameObject GetFurniture()
    {
        return furniture;
    }

    // From here
    public Sprite GetFurnitureImage()
    {
        return furniture_img;
    }

    public string GetFurnitureName()
    {
        return furniture_name;
    }

    public string GetFurnitureSeller()
    {
        return seller;
    }

    public string GetFurnitureMaterials()
    {
        return materials_used;
    }

    public string GetFurniturePrice()
    {
        return price;
    }

    public string GetFurnitureDimensions()
    {
        return dimensions;
    }

    public string GetFurnitureDescription()
    {
        return description;
    }

    public int GetVariantNumbers()
    {
        return v_number;
    }
    public Sprite GetVariant1()
    {
        return v1;
    }

    public Sprite GetVariant2()
    {
        return v2;
    }

    public Sprite GetVariant3()
    {
        return v3;
    }

    public Sprite GetVariant4()
    {
        return v4;
    }
    public string GetHyperlinkToBuy()
    {
        return HyperLink;
    }


    //To here

    public async Task Get(String label)
    {
        var locations = await Addressables.LoadResourceLocationsAsync(label).Task;
        foreach (var location in locations)
        {
            var obj = await Addressables.LoadAssetAsync<Item>(location).Task;
            _items.Add(obj);
        }
    }  
}
