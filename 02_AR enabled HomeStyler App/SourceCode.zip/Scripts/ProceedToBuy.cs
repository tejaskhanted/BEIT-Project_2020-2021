using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProceedToBuy : MonoBehaviour
{
    private string LinkToBuy;

    private void Update()
    {
        LinkToBuy = DataHandler.Instance.GetHyperlinkToBuy();
    }
    public void OpenURL()
    {
        Application.OpenURL(LinkToBuy);
    }
}
