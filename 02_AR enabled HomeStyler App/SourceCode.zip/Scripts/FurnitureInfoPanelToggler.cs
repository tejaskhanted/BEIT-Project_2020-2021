using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FurnitureInfoPanelToggler : MonoBehaviour
{
    [SerializeField]private GameObject InfoPanel;

    public void OpenPanel()
    {
        if (InfoPanel != null)
        {
            bool isActive = InfoPanel.activeSelf;

            InfoPanel.SetActive(!isActive);

        }
    }
}
