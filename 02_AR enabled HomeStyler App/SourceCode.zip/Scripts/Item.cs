﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Item1", menuName = "AddItem/Item")]

public class Item : ScriptableObject
{
    public string ItemName;
    public string Seller;
    public string price;
    public string Dimensions;
    public string Material;
    public GameObject itemPrefab;
    public Sprite itemImage;
    public string Description;
    public int VariantNumbers;
    public Sprite VariantImage1;
    public Sprite VariantImage2;
    public Sprite VariantImage3;
    public Sprite VariantImage4;
    public string Hyperlink;
}
