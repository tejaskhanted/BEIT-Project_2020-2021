using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TakeScreenShot : MonoBehaviour
{
    [SerializeField] GameObject blink;

    public void TakeAShot()
    {
        StartCoroutine("CaptureIt");
    }

    IEnumerator CaptureIt()
    {
        string timeStamp = System.DateTime.Now.ToString("dd-MM-yyyy-HH-mm-ss");
        string fileName = "ScreenShot" + timeStamp + ".png";
        string pathToSave = fileName;
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
        ScreenCapture.CaptureScreenshot(pathToSave);
        yield return new WaitForEndOfFrame();
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
        Instantiate(blink, new Vector2(0f, 0f), Quaternion.identity);
    }
}
