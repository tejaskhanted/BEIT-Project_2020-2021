using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FurnitureInfoDisplay : MonoBehaviour
{
    [SerializeField] private RawImage Item_Image;
    [SerializeField] private Text Item_Name;
    [SerializeField] private Text Item_Seller;
    [SerializeField] private Text Materials_Used;
    [SerializeField] private Text Item_Price;
    [SerializeField] private Text Item_Dimensions;
    [SerializeField] private Text Item_Description;
    [SerializeField] private Text NumberOfVariants;
    [SerializeField] private RawImage Variant1;
    [SerializeField] private RawImage Variant2;
    [SerializeField] private RawImage Variant3;
    [SerializeField] private RawImage Variant4;

    private void Update()
    {
        Item_Image.texture = DataHandler.Instance.GetFurnitureImage().texture;
        Item_Name.text = DataHandler.Instance.GetFurnitureName();
        Item_Seller.text = DataHandler.Instance.GetFurnitureSeller();
        Item_Price.text = DataHandler.Instance.GetFurniturePrice();
        Materials_Used.text = DataHandler.Instance.GetFurnitureMaterials();
        Item_Dimensions.text = DataHandler.Instance.GetFurnitureDimensions();
        Item_Description.text = DataHandler.Instance.GetFurnitureDescription();
        NumberOfVariants.text = DataHandler.Instance.GetVariantNumbers().ToString();
        Variant1.texture = DataHandler.Instance.GetVariant1().texture;
        Variant2.texture = DataHandler.Instance.GetVariant2().texture;
        Variant3.texture = DataHandler.Instance.GetVariant3().texture;
        Variant4.texture = DataHandler.Instance.GetVariant4().texture;
    }
}
