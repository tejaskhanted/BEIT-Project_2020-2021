using UnityEngine;

public class ContentBehaviour : MonoBehaviour
{
    public GameObject furnitureObj;

    public void RemoveButtonDown()
    {
        Destroy(furnitureObj);
    }
}