using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookAt : MonoBehaviour
{
    [SerializeField] Transform MainCam;

    private void Start()
    {
        MainCam = Camera.main.transform;
    }

    private void Update()
    {
        transform.LookAt(MainCam);
    }
}
