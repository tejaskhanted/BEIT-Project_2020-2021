using System.Collections;
using UnityEngine;

public class ChangeTextures : MonoBehaviour
{
    public Texture[] textures;
    public int currentTexture;

    public void SwapTexture()
    {
        currentTexture++;
        currentTexture %= textures.Length;
        GetComponent<Renderer>().material.mainTexture = textures[currentTexture];
    }
}