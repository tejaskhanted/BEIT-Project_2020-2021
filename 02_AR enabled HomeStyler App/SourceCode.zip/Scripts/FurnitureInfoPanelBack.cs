using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FurnitureInfoPanelBack : MonoBehaviour
{
    public GameObject InformationPanel;

    public void closePanel()
    {
        InformationPanel.SetActive(false);
    }
}
