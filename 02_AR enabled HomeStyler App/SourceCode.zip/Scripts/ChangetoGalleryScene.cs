using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ChangetoGalleryScene : MonoBehaviour
{
    [SerializeField] GameObject GalleryPanel;

    public void ActiveGallleryPanel()
    {
        GalleryPanel.SetActive(true);
    }

    public void DeactiveGalleryPanel()
    {
        GalleryPanel.SetActive(false);
    }
}
